<?php

namespace App\Models;

use CodeIgniter\Model;

class DictaModel extends Model
{
    protected $table = 'dicta';
    protected $primaryKey = 'id';
    protected $allowedFields = ['profesor', 'materia', 'inicio', 'baja', 'condicion'];
    protected $validationRules = [
        'profesor' => 'required',
        'materia' => 'required',
        'inicio' => 'required|date',
        'condicion' => 'required'
    ];
    public function profesor()
    {
        return $this->belongsTo(ProfesorModel::class, 'profesor', 'id');
    }

    public function materia()
    {
        return $this->belongsTo(MateriaModel::class, 'materia', 'id');
    }
    protected $returnType = 'object';

    protected $useSoftDeletes = true;
    protected $deletedField = 'baja';
}
