<?php

namespace App\Models;

use CodeIgniter\Model;

class ProfesorModel extends Model
{
    protected $table = 'profesores';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nombre', 'apellido', 'dni', 'cuil', 'titulo', 'cbu', 'matricula'];
    protected $validationRules = [
        'nombre' => 'required',
        'apellido' => 'required',
        'dni' => 'required|numeric',
        'cuil' => 'required|numeric',
        'titulo' => 'required',
        'cbu' => 'required|numeric',
        'matricula' => 'required|numeric'
    ];
    public function materias()
    {
        return $this->hasMany('DictaModel', 'profesor', 'materia');
    }
}
