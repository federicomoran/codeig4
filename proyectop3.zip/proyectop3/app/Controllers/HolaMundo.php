<?php

namespace App\Controllers;

class HolaMundo extends BaseController
{
    public function index(): string
    {
        return view('vista_hola_mundo');
    }
     public function desdeSubCarpeta(): string
    {
        return view('vista_hola_mundo');
    }
}
