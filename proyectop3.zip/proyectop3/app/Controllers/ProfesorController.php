<?php

namespace App\Controllers;

use App\Models\ProfesorModel;
use App\Models\DictaModel;

class ProfesorController extends BaseController
{
    public function index()
    {
        $model = new ProfesorModel();
        $data['profesores'] = $model->findAll();


        return view('profesor/index', $data);
    }

    public function create()
    {
        return view('profesor/create');
    }

    public function store()
    {
        $model = new ProfesorModel();

        $uploadDirectory = getenv('UPLOADS_DIRECTORY');

        $allowedFileTypes = explode(',', getenv('ALLOWED_FILE_TYPES'));

        $tituloFile = $this->request->getFile('titulo');

        if ($tituloFile === null) {
            return redirect()->to('/profesor/create')
                ->with('error', 'Debes seleccionar un archivo para el título.');
        }

        if ($tituloFile->isValid() && $tituloFile->getSize() > 0) {
            $newName = $tituloFile->getRandomName();
            $destination = WRITEPATH . 'public/upload/' . $uploadDirectory;

            if ($tituloFile->move($destination, $newName)) {
                $dni = $this->request->getVar('dni');
                $cuil = $this->request->getVar('cuil');
                $cbu = $this->request->getVar('cbu');
                $matricula = $this->request->getVar('matricula');

                $existingDNI = $model->where('dni', $dni)->first();
                if ($existingDNI) {
                    return redirect()->to('/profesor/create')
                        ->with('error', 'El DNI ya está siendo utilizado por otro profesor.');
                }

                $existingCUIL = $model->where('cuil', $cuil)->first();
                if ($existingCUIL) {
                    return redirect()->to('/profesor/create')
                        ->with('error', 'El CUIL ya está siendo utilizado por otro profesor.');
                }

                $existingCBU = $model->where('cbu', $cbu)->first();
                if ($existingCBU) {
                    return redirect()->to('/profesor/create')
                        ->with('error', 'El CBU ya está siendo utilizado por otro profesor.');
                }


                $existingMatricula = $model->where('matricula', $matricula)->first();

                if ($existingMatricula) {
                    return redirect()->to('/profesor/create')
                        ->with('error', 'La matrícula ya está siendo utilizada por otro profesor.');
                }

                $data = [
                    'nombre' => $this->request->getVar('nombre'),
                    'apellido' => $this->request->getVar('apellido'),
                    'dni' => $this->request->getVar('dni'),
                    'cuil' => $this->request->getVar('cuil'),
                    'titulo' => $newName,
                    'cbu' => $this->request->getVar('cbu'),
                    'matricula' => $this->request->getVar('matricula'),
                ];

                $model->insert($data);

                return redirect()->to('/profesor');
            } else {
                $error = $tituloFile->getErrorString();
                return redirect()->to('/profesor/create')
                    ->with('error', 'Error al cargar el archivo del título. Error: ' . $error);
            }
        } else {
            return redirect()->to('/profesor/create')
                ->with('error', 'Error al cargar el archivo del título.');
        }

        return redirect()->to('/profesor');
    }

    public function edit($id)
    {
        $model = new ProfesorModel();
        $data['profesor'] = $model->find($id);

        return view('profesor/edit', $data);
    }

    public function update($id)
    {
        $model = new ProfesorModel();

        $data = [
            'nombre' => $this->request->getVar('nombre'),
            'apellido' => $this->request->getVar('apellido'),
            'dni' => $this->request->getVar('dni'),
            'cuil' => $this->request->getVar('cuil'),
            'titulo' => $this->request->getVar('titulo'),
            'cbu' => $this->request->getVar('cbu'),
            'matricula' => $this->request->getVar('matricula')
        ];

        $tituloFile = $this->request->getFile('titulo');

        if ($tituloFile->isValid() && $tituloFile->getSize() > 0) {
            $newName = $tituloFile->getRandomName();

            $destination = WRITEPATH . 'public/uploads';

            if ($tituloFile->move($destination, $newName)) {
                $data['titulo'] = $newName;
            } else {
                $error = $tituloFile->getErrorString();
                return redirect()->to('/profesor/edit/' . $id)
                    ->with('error', 'Error al cargar el archivo del título. Error: ' . $error);
            }
        }

        $existingDNI = $model->where('dni', $data['dni'])->where('id !=', $id)->first();

        if ($existingDNI) {
            return redirect()->to('/profesor/edit/' . $id)
                ->with('error', 'El DNI ya está siendo utilizado por otro profesor.');
        }

        $existingCUIL = $model->where('cuil', $data['cuil'])->where('id !=', $id)->first();

        if ($existingCUIL) {
            return redirect()->to('/profesor/edit/' . $id)
                ->with('error', 'El CUIL ya está siendo utilizado por otro profesor.');
        }

        $existingCBU = $model->where('cbu', $data['cbu'])->where('id !=', $id)->first();

        if ($existingCBU) {
            return redirect()->to('/profesor/edit/' . $id)
                ->with('error', 'El CBU ya está siendo utilizado por otro profesor.');
        }

        $existingMatricula = $model->where('matricula', $data['matricula'])->where('id !=', $id)->first();

        if ($existingMatricula) {
            return redirect()->to('/profesor/edit/' . $id)
                ->with('error', 'La matrícula ya está siendo utilizada por otro profesor.');
        }

        $model->skipValidation(true);


        if ($model->update($id, $data)) {
            return redirect()->to('/profesor');
        } else {

            $data['profesor'] = $model->find($id);
            $data['validation'] = $model->errors();
            return view('profesor/edit', $data);
        }
    }

    public function delete($id)
    {
        $model = new ProfesorModel();
        $model->delete($id);

        return redirect()->to('/profesor');
    }
}
