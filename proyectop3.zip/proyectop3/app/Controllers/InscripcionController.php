<?php

namespace App\Controllers;

use App\Models\AlumnoModel;
use App\Models\MateriaModel;
use App\Models\CursaModel; 

class InscripcionController extends BaseController
{
    public function index()
    {
        $alumnoModel = new AlumnoModel();
        $materiaModel = new MateriaModel();

        $data['alumnos'] = $alumnoModel->findAll();
        $data['materias'] = $materiaModel->findAll();

        return view('inscripcion/formulario', $data);
    }

    public function guardarInscripcion()
    {
        $id_alumno = $this->request->getVar('id_alumno');
        $id_materia = $this->request->getVar('id_materia');

        $cursaModel = new CursaModel(); 

        
        if ($cursaModel->where('alumno', $id_alumno)->where('materia', $id_materia)->first() !== null) {
            return redirect()->to('/inscripcion')->with('error', 'La inscripción ya existe.');
        }

        $data = [
            'alumno' => $id_alumno, 
            'materia' => $id_materia, 
            'division' => 1, 
            'fecha' => date('Y-m-d'), 
        ];

        $cursaModel->insert($data);

        return redirect()->to('/inscripcion')->with('success', 'Inscripción exitosa.');
    }
}
