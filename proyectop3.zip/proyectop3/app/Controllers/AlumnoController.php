<?php

namespace App\Controllers;

use App\Models\AlumnoModel;

class AlumnoController extends BaseController
{
    public function index()
    {
        $model = new AlumnoModel();
        $data['alumnos'] = $model->findAll();
        
        return view('alumno/index', $data);
    }

    public function create()
    {
        return view('alumno/create');
    }

    public function store()
    {
        $model = new AlumnoModel();
        
        $data = [
            'nombre' => $this->request->getVar('nombre'),
            'apellido' => $this->request->getVar('apellido'),
            'dni' => $this->request->getVar('dni'),
            'mail' => $this->request->getVar('mail'),
            'cuil' => $this->request->getVar('cuil'),
            'telefono' => $this->request->getVar('telefono'),
            'domicilio' => $this->request->getVar('domicilio'),
            'localidad' => $this->request->getVar('localidad')
        ];

        
		$existingAlumno = $model->where('dni', $data['dni'])
                ->orWhere('cuil', $data['cuil'])
                ->first();

    if ($existingAlumno) {
        return redirect()->to('/alumno/create')
            ->with('error', 'El DNI o CUIL ya está siendo utilizado por otro alumno.');
    }
        $model->insert($data);
        
        return redirect()->to('/alumno');
    }

    public function edit($id)
    {
        $model = new AlumnoModel();
        $data['alumno'] = $model->find($id);
        
        return view('alumno/edit', $data);
    }

    public function update($id)
{
    $model = new AlumnoModel();

    $data = [
        'nombre' => $this->request->getVar('nombre'),
        'apellido' => $this->request->getVar('apellido'),
        'dni' => $this->request->getVar('dni'),
        'mail' => $this->request->getVar('mail'),
        'cuil' => $this->request->getVar('cuil'),
        'telefono' => $this->request->getVar('telefono'),
        'domicilio' => $this->request->getVar('domicilio'),
        'localidad' => $this->request->getVar('localidad')
    ];

    $existingDNI = $model->where('dni', $data['dni'])->where('id !=', $id)->first();

    if ($existingDNI) {
        return redirect()->to('/alumno/edit/' . $id)
            ->with('error', 'El DNI ya está siendo utilizado por otro alumno.');
    }

    $existingCUIL = $model->where('cuil', $data['cuil'])->where('id !=', $id)->first();

    if ($existingCUIL) {
        return redirect()->to('/alumno/edit/' . $id)
            ->with('error', 'El CUIL ya está siendo utilizado por otro alumno.');
    }
  $model->skipValidation(true);

    
    if ($model->update($id, $data)) {
        return redirect()->to('/alumno');
    } else {
        
        $data['alumno'] = $model->find($id);
        $data['validation'] = $model->errors();
        return view('alumno/edit', $data);
    }
    }


    public function delete($id)
    {
        $model = new AlumnoModel();
        $model->delete($id);
        
        return redirect()->to('/alumno');
    }
}
