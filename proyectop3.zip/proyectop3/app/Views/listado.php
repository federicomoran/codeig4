<!DOCTYPE html>
<html lang="es">

<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Listado</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="centered-container">
        <h1>Listado de profesores con sus respectivas materias.</h1>

        <table>
            <thead>
                <tr>
                    <th>Nombre Completo</th>
                    <th>Materia</th>
                    <th>Condicion</th>
                    <th>Fecha de alta</th>
                    <th>Accion</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($listado as $lista) : ?>
                    <tr>
                        <td><?= esc($lista->profesor_nombre . ' ' . $lista->profesor_apellido) ?></td>
                        <td><?= esc($lista->materia_nombre) ?></td>
                        <td><?= esc($lista->condicion) ?></td>
                        <td><?= esc(date('d/m/Y', strtotime($lista->inicio))) ?></td>
                        <td>
                            <a href="<?= site_url("/eliminarDicta/{$lista->id}") ?>" onclick="return confirm('¿Seguro que desea eliminar esta inscripción?')">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <br>
        <a href="<?= site_url('dicta') ?>">Agregar nuevo profesor para dictar una materia</a>
        <br>
        <a href="<?= site_url('profesor') ?>">Ir al listado de profesores</a>
        <br>
        <a href="<?= site_url('materia') ?>">Ir al listado de materias</a>
    </div>
</body>

</html>