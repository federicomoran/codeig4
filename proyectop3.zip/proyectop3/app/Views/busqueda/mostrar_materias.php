<!DOCTYPE html>
<html lang="es">

<head>
    <?php if (session()->has('success')) : ?>
        <div class="alert alert-success">
            <?= session('success') ?>
        </div>
    <?php endif; ?>

    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Materias que dicta el docente</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="centered-container">
        <h1>Materias que el docente dicta</h1>

        <p><b>Nombre completo del docente:</b> <?= esc($profesor['nombre'] . ' ' . $profesor['apellido']) ?></p>
        <p><b>DNI:</b> <?= esc($profesor['dni']) ?></p>

        <h2>Materias que dicta:</h2>

        <ul>
            <?php foreach ($materiasInscriptas as $materia) : ?>
                <li>
                    <?= esc($materia['nombre']) ?> - Año <?= esc($materia['anno']) ?> - Semestre <?= esc($materia['semestre']) ?>
                </li>
            <?php endforeach; ?>
        </ul>

        <a href="<?= site_url('buscar_materia') ?>">Volver</a>
    </div>
</body>

</html>