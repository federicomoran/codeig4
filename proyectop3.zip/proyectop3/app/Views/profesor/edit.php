<!DOCTYPE html>
<html lang="es">
<head>
       <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
   <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Editar Profesor</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
        
    </style>
</head>
<body>
    <div class="centered-container">
<?php if (session()->has('error')) : ?>
    <div class="alert alert-danger">
        <?= session('error') ?>
    </div>
<?php endif; ?>

<h1>Editar Profesor</h1>

<form method="post" action="<?= site_url('profesor/update/' . $profesor['id']) ?>" enctype="multipart/form-data">

    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" value="<?= $profesor['nombre']; ?>" required><br>

    <label for="apellido">Apellido:</label>
    <input type="text" name="apellido" value="<?= $profesor['apellido']; ?>" required><br>

    <label for="dni">DNI:</label>
    <input type="text" name="dni" pattern="[0-9]+"  value="<?= $profesor['dni']; ?>" required><br>

    <label for="cuil">CUIL:</label>
    <input type="text" name="cuil" pattern="[0-9]+" value="<?= $profesor['cuil']; ?>" required><br>

    <label for="titulo">Titulo (Cargar Archivo):</label>
    <input type="file" name="titulo" accept=".pdf, .doc, .docx">
    <?php if (session()->has('error_titulo')) : ?>
        <p class="text-danger"><?= session('error_titulo') ?></p> 
    <?php endif; ?> <br>

    <label for="cbu">CBU:</label>
    <input type="text" name="cbu" pattern="[0-9]+"  value="<?= $profesor['cbu']; ?>" required><br>

    <label for="matricula">Matricula:</label>
    <input type="text" name="matricula" pattern="[0-9]+" value="<?= $profesor['matricula']; ?>" required><br>

    <input type="submit" value="Guardar">
</form>

<a href="<?= site_url('profesor') ?>">Volver a la lista</a>
</body>
</html>