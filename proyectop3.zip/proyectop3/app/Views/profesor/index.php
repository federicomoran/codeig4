<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Lista de Profesores</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }

        .volver-btn {
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            position: absolute;
            right: 550px;
            bottom: 20px;
        }

        .volver-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <a href="<?= site_url('/') ?>" class="volver-btn">Volver al Menú</a>
    <div class="centered-container">
        <h1>Lista de Profesores</h1>

        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>DNI</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($profesores as $profesor) : ?>
                    <tr>
                        <td><?= $profesor['nombre']; ?></td>
                        <td><?= $profesor['apellido']; ?></td>
                        <td><?= $profesor['dni']; ?></td>
                        <td>
                            <a href="<?= site_url('profesor/edit/' . $profesor['id']) ?>">Editar</a>
                            <a href="<?= site_url('profesor/delete/' . $profesor['id']) ?>" onclick="return confirm('¿Seguro que desea eliminar?')">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="<?= site_url('profesor/create') ?>">Agregar nuevo profesor</a>
        <a href="<?= site_url('dicta') ?>">Inscribir profesor dictante a materia</a>
        <a href="<?= site_url('buscar_materia') ?>">Ver materias que dictan los docentes en base a su DNI</a>

    </div>
    <br> <br> <br> <br>
    <footer style="background-color: yellow; color: black; font-weight: bold; text-align: center;">
        Desarrollado por Facundo Simeoni y Federico Moran.
    </footer>
</body>

</html>