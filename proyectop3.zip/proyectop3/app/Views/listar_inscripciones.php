<!DOCTYPE html>
<html lang="es">
<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Lista de Inscripciones</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="centered-container">
    <h1>Lista de Inscripciones</h1>

<?php if (session()->has('success')): ?>
        <div class="alert alert-success">
            <?= session('success') ?>
        </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Alumno</th>
                <th>Materia</th>
                <th>División</th>
                <th>Fecha</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($inscripciones as $inscripcion) : ?>
                <tr>
                    <td><?= esc($inscripcion->alumno_nombre . ' ' . $inscripcion->alumno_apellido) ?></td>
                    <td><?= esc($inscripcion->materia_nombre) ?></td>
                    <td><?= esc($inscripcion->division) ?></td>
                    <td><?= esc($inscripcion->fecha) ?></td>
                    <td>
                        <a href="<?= site_url("/eliminarInscripcion/{$inscripcion->id}") ?>" onclick="return confirm('¿Seguro que desea eliminar esta inscripción?')">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="<?= site_url('alumno') ?>">Volver a la lista de Alumnos</a>
</body>
</html>
