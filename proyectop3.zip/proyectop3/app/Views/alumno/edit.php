<!DOCTYPE html>
<html lang="es">
<head>
       <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
   <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Editar Alumno</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
        
    </style>
</head>
<body>
    <div class="centered-container">
<?php if (session()->has('error')) : ?>
    <div class="alert alert-danger">
        <?= session('error') ?>
    </div>
<?php endif; ?>

<h1>Editar Alumno</h1>

<form method="post" action="<?= site_url('alumno/update/' . $alumno['id']) ?>">

    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" value="<?= $alumno['nombre']; ?>" required><br>

    <label for="apellido">Apellido:</label>
    <input type="text" name="apellido" value="<?= $alumno['apellido']; ?>" required><br>

    <label for="dni">DNI:</label>
    <input type="text" name="dni" pattern="[0-9]+"  value="<?= $alumno['dni']; ?>" required><br>

    <label for="mail">Mail:</label>
    <input type="email" name="mail" value="<?= $alumno['mail']; ?>" required><br>

    <label for="cuil">CUIL:</label>
    <input type="text" name="cuil" pattern="[0-9]+"  value="<?= $alumno['cuil']; ?>" required><br>

    <label for="telefono">Teléfono:</label>
    <input type="text" name="telefono" pattern="[0-9]+"  value="<?= $alumno['telefono']; ?>" required><br>

    <label for="domicilio">Domicilio:</label>
    <input type="text" name="domicilio" value="<?= $alumno['domicilio']; ?>" required><br>

    <label for="localidad">Localidad:</label>
    <select name="localidad" required>
        <option value="Caucete" <?= ($alumno['localidad'] == 'Localidad1') ? 'selected' : ''; ?>>Caucete</option>
        <option value="25 de Mayo" <?= ($alumno['localidad'] == 'Localidad2') ? 'selected' : ''; ?>>25 de Mayo</option>
        <option value="San Martin" <?= ($alumno['localidad'] == 'Localidad3') ? 'selected' : ''; ?>>San Martin</option>
        <option value="9 de Julio" <?= ($alumno['localidad'] == 'Localidad4') ? 'selected' : ''; ?>>9 de Julio</option>
    </select><br>

    <input type="submit" value="Guardar">
</form>

<a href="<?= site_url('alumno') ?>">Volver a la lista</a>
</body>
</html>