<!DOCTYPE html>
<html lang="es">

<head>
    <img src="<?= base_url('public/imagenes/logo_ies.jpg') ?>" alt="Escuela">
    <img src="<?= base_url('public/imagenes/fondo_esc.jpg') ?>" alt="Logo">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url('/public/css/styles.css') ?>">
    <title>Editar Plan</title>
    <style>
        .centered-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .centered-container h1 {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="centered-container">
        <?php if (session()->has('error')) : ?>
            <div class="alert alert-danger">
                <?= session('error') ?>
            </div>
        <?php endif; ?>

        <h1>Editar plan de estudio</h1>

        <form method="post" action="<?= site_url('plan/update/' . $plan['id']) ?>">

            <label for="numero">Numero de resolucion</label>
            <input type="text" name="num_res" value="<?= $plan['num_res']; ?>" required><br><br>

            <label for="titulo">Titulo</label>
            <input type="text" name="titulo" value="<?= $plan['titulo']; ?>" required><br><br>

            <label for="estado">Estado</label>
            <input type="text" name="estado" value="<?= $plan['estado']; ?>" required><br><br>
            <br>
            <input type="submit" value="Guardar">
        </form>
        <br>

        <a href="<?= site_url('plan') ?>">Volver a la lista</a>
</body>

</html>