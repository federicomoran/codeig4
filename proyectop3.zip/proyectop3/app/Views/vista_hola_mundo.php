<?php
echo "Hola mundo desde la vista";
?>