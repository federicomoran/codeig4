<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/alumno', 'AlumnoController::index');
$routes->get('/alumno/create', 'AlumnoController::create');
$routes->post('/alumno/store', 'AlumnoController::store');
$routes->get('/alumno/edit/(:num)', 'AlumnoController::edit/$1');
$routes->post('/alumno/update/(:num)', 'AlumnoController::update/$1');
$routes->get('/alumno/delete/(:num)', 'AlumnoController::delete/$1');
$routes->get('/profesor', 'ProfesorController::index');
$routes->get('/profesor/create', 'ProfesorController::create');
$routes->post('/profesor/store', 'ProfesorController::store');
$routes->get('/profesor/edit/(:num)', 'ProfesorController::edit/$1');
$routes->post('/profesor/update/(:num)', 'ProfesorController::update/$1');
$routes->get('/profesor/delete/(:num)', 'ProfesorController::delete/$1');
$routes->get('/plan', 'PlanController::index');
$routes->get('/plan/create', 'PlanController::create');
$routes->post('/plan/store', 'PlanController::store');
$routes->get('/plan/edit/(:num)', 'PlanController::edit/$1');
$routes->post('/plan/update/(:num)', 'PlanController::update/$1');
$routes->get('/plan/delete/(:num)', 'PlanController::delete/$1');
$routes->get('/plan/materias/(:num)', 'PlanController::materias/$1');
$routes->get('/materia', 'MateriaController::index');
$routes->get('/materia/create', 'MateriaController::create');
$routes->post('/materia/store', 'MateriaController::store');
$routes->get('/materia/edit/(:num)', 'MateriaController::edit/$1');
$routes->post('/materia/update/(:num)', 'MateriaController::update/$1');
$routes->get('/materia/delete/(:num)', 'MateriaController::delete/$1');
$routes->get('/inscripcion', 'InscripcionController::index');
$routes->post('/guardar', 'InscripcionController::guardarInscripcion');
$routes->get('/buscar', 'BusquedaController::buscarAlumno');
$routes->post('/mostrar', 'BusquedaController::mostrarInscripciones');
$routes->get('listar-inscripciones', 'BusquedaController::listarInscripciones');
$routes->get('eliminarInscripcion/(:num)', 'BusquedaController::eliminarInscripcion/$1');
$routes->get('eliminar-inscripcion/(:num)/(:num)', 'BusquedaController::eliminarInscripcion/$1/$2');
$routes->get('/dicta', 'DictaController::index');
$routes->post('/guardarDicta', 'DictaController::guardarDicta');
$routes->get('/listado', 'DictaController::listado');
$routes->get('eliminarDicta/(:num)', 'DictaController::eliminarDicta/$1');
$routes->get('eliminar-Dicta/(:num)/(:num)', 'DictaController::eliminarDicta/$1/$2');
$routes->get('profesor/materias/(:num)', 'ProfesorController::materias/$1');
$routes->get('/buscar_materia', 'BusquedaController::buscarMateria');
$routes->post('/mostrar_materias', 'BusquedaController::mostrarMaterias');




$routes->setAutoRoute(true);
